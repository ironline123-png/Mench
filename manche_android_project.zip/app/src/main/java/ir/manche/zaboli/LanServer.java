package ir.manche.zaboli;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/** سرور HTTP + WebSocket بسیار کوچک و بدون وابستگی بیرونی. صفحهٔ بازی را می‌دهد و پیام‌ها را به میزبان می‌رساند. */
public class LanServer {
    public interface Listener {
        void onMessage(String clientId, String text);
        void onClose(String clientId);
    }

    private final int port;
    private final byte[] page;
    private final Listener listener;
    private ServerSocket server;
    private volatile boolean running;
    private final ConcurrentHashMap<String, Conn> conns = new ConcurrentHashMap<>();
    private final AtomicInteger nextId = new AtomicInteger(1);

    public LanServer(int port, byte[] page, Listener listener) {
        this.port = port;
        this.page = page;
        this.listener = listener;
    }

    public void start() throws IOException {
        server = new ServerSocket();
        server.setReuseAddress(true);
        server.bind(new InetSocketAddress(port));
        running = true;
        Thread t = new Thread(new Runnable() {
            public void run() {
                while (running) {
                    try {
                        final Socket s = server.accept();
                        Thread h = new Thread(new Runnable() { public void run() { handle(s); } });
                        h.setDaemon(true);
                        h.start();
                    } catch (IOException e) {
                        if (!running) return;
                    }
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    public void stop() {
        running = false;
        try { if (server != null) server.close(); } catch (IOException ignored) { }
        for (Conn c : new ArrayList<>(conns.values())) c.closeQuietly();
        conns.clear();
    }

    /** to == "*" برای همه، وگرنه شناسهٔ کلاینت */
    public void send(String to, String text) {
        byte[] f = frame(1, text.getBytes(StandardCharsets.UTF_8));
        if ("*".equals(to)) {
            for (Conn c : conns.values()) c.write(f);
        } else {
            Conn c = conns.get(to);
            if (c != null) c.write(f);
        }
    }

    private static class Conn {
        final Socket socket;
        final OutputStream out;
        Conn(Socket s, OutputStream o) { socket = s; out = o; }
        void write(byte[] data) {
            try { synchronized (out) { out.write(data); out.flush(); } } catch (IOException e) { closeQuietly(); }
        }
        void closeQuietly() { try { socket.close(); } catch (IOException ignored) { } }
    }

    static byte[] frame(int op, byte[] payload) {
        ByteArrayOutputStream b = new ByteArrayOutputStream(payload.length + 10);
        b.write(0x80 | op);
        int len = payload.length;
        if (len < 126) b.write(len);
        else if (len < 65536) { b.write(126); b.write(len >> 8); b.write(len & 0xff); }
        else {
            b.write(127);
            for (int i = 7; i >= 0; i--) b.write((int) (((long) len >> (8 * i)) & 0xff));
        }
        b.write(payload, 0, payload.length);
        return b.toByteArray();
    }

    private void handle(Socket s) {
        String id = null;
        try {
            s.setTcpNoDelay(true);
            InputStream in = s.getInputStream();
            OutputStream out = s.getOutputStream();
            // خواندن سرآیند HTTP
            ByteArrayOutputStream hb = new ByteArrayOutputStream();
            int last4 = 0, ch;
            while ((ch = in.read()) >= 0) {
                hb.write(ch);
                last4 = (last4 << 8) | ch;
                if (last4 == 0x0d0a0d0a) break;
                if (hb.size() > 16384) { s.close(); return; }
            }
            if (ch < 0) { s.close(); return; }
            String head = new String(hb.toByteArray(), StandardCharsets.ISO_8859_1);
            String[] lines = head.split("\r\n");
            String reqLine = lines.length > 0 ? lines[0] : "";
            String key = null;
            boolean upgrade = false;
            for (int i = 1; i < lines.length; i++) {
                int c = lines[i].indexOf(':');
                if (c < 0) continue;
                String k = lines[i].substring(0, c).trim().toLowerCase();
                String v = lines[i].substring(c + 1).trim();
                if (k.equals("sec-websocket-key")) key = v;
                if (k.equals("upgrade") && v.equalsIgnoreCase("websocket")) upgrade = true;
            }
            if (upgrade && key != null) {
                String acc = b64(MessageDigest.getInstance("SHA-1")
                        .digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.ISO_8859_1)));
                String resp = "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + acc + "\r\n\r\n";
                out.write(resp.getBytes(StandardCharsets.ISO_8859_1));
                out.flush();
                id = "c" + nextId.getAndIncrement();
                Conn conn = new Conn(s, out);
                conns.put(id, conn);
                s.setSoTimeout(0);
                wsLoop(id, conn, in);
            } else {
                String path = reqLine.split(" ").length > 1 ? reqLine.split(" ")[1] : "/";
                int q = path.indexOf('?');
                if (q >= 0) path = path.substring(0, q);
                byte[] body; String type; String status;
                if (path.equals("/") || path.equals("/index.html")) { body = page; type = "text/html; charset=utf-8"; status = "200 OK"; }
                else if (path.equals("/favicon.ico")) { body = new byte[0]; type = "image/x-icon"; status = "204 No Content"; }
                else { body = "Not found".getBytes(StandardCharsets.UTF_8); type = "text/plain; charset=utf-8"; status = "404 Not Found"; }
                String h = "HTTP/1.1 " + status + "\r\nContent-Type: " + type + "\r\nContent-Length: " + body.length + "\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n";
                out.write(h.getBytes(StandardCharsets.ISO_8859_1));
                out.write(body);
                out.flush();
                s.close();
            }
        } catch (Exception e) {
            try { s.close(); } catch (IOException ignored) { }
        } finally {
            if (id != null) {
                conns.remove(id);
                try { listener.onClose(id); } catch (Exception ignored) { }
            }
        }
    }

    private void wsLoop(String id, Conn conn, InputStream in) throws IOException {
        ByteArrayOutputStream frag = new ByteArrayOutputStream();
        long t0 = System.currentTimeMillis();
        int count = 0;
        while (running) {
            int b0 = in.read();
            if (b0 < 0) return;
            int b1 = in.read();
            if (b1 < 0) return;
            boolean fin = (b0 & 0x80) != 0;
            int op = b0 & 0x0f;
            boolean masked = (b1 & 0x80) != 0;
            long len = b1 & 0x7f;
            if (len == 126) { len = (readByte(in) << 8) | readByte(in); }
            else if (len == 127) { len = 0; for (int i = 0; i < 8; i++) len = (len << 8) | readByte(in); }
            if (len > (1 << 18)) return;
            byte[] mask = new byte[4];
            if (masked) readFully(in, mask, 4);
            byte[] payload = new byte[(int) len];
            readFully(in, payload, payload.length);
            if (masked) for (int i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
            if (op == 8) { conn.write(frame(8, new byte[0])); return; }
            if (op == 9) { conn.write(frame(10, payload)); continue; }
            if (op == 10) continue;
            if (op == 0 || op == 1) {
                if (op == 1) frag.reset();
                frag.write(payload, 0, payload.length);
                if (frag.size() > (1 << 18)) return;
                if (fin) {
                    String text = new String(frag.toByteArray(), StandardCharsets.UTF_8);
                    frag.reset();
                    long now = System.currentTimeMillis();
                    if (now - t0 > 1000) { t0 = now; count = 0; }
                    if (++count > 30) continue; // محدودیت نرخ
                    listener.onMessage(id, text);
                }
            }
        }
    }

    private static String b64(byte[] d) {
        final String T = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < d.length; i += 3) {
            int n = (d[i] & 0xff) << 16 | (i + 1 < d.length ? (d[i + 1] & 0xff) << 8 : 0) | (i + 2 < d.length ? (d[i + 2] & 0xff) : 0);
            sb.append(T.charAt((n >> 18) & 63)).append(T.charAt((n >> 12) & 63));
            sb.append(i + 1 < d.length ? T.charAt((n >> 6) & 63) : '=');
            sb.append(i + 2 < d.length ? T.charAt(n & 63) : '=');
        }
        return sb.toString();
    }

    private static int readByte(InputStream in) throws IOException {
        int b = in.read();
        if (b < 0) throw new IOException("eof");
        return b;
    }

    private static void readFully(InputStream in, byte[] buf, int n) throws IOException {
        int off = 0;
        while (off < n) {
            int r = in.read(buf, off, n - off);
            if (r < 0) throw new IOException("eof");
            off += r;
        }
    }

    /** همهٔ آدرس‌های IPv4 این دستگاه (به‌جز loopback) */
    public static List<String> localIps() {
        List<String> r = new ArrayList<>();
        try {
            java.util.Enumeration<java.net.NetworkInterface> ifs = java.net.NetworkInterface.getNetworkInterfaces();
            while (ifs != null && ifs.hasMoreElements()) {
                java.net.NetworkInterface ni = ifs.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                java.util.Enumeration<java.net.InetAddress> as = ni.getInetAddresses();
                while (as.hasMoreElements()) {
                    java.net.InetAddress a = as.nextElement();
                    if (a instanceof java.net.Inet4Address && !a.isLoopbackAddress()) r.add(a.getHostAddress());
                }
            }
        } catch (Exception ignored) { }
        return r;
    }
}
