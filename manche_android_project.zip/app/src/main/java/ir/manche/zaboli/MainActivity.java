package ir.manche.zaboli;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.List;

public class MainActivity extends Activity {
    private WebView web;
    private LanServer server;
    private byte[] pageBytes;
    private static final int PORT = 8080;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        setContentView(web);
        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setMediaPlaybackRequiresUserGesture(false);
        st.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Bridge(), "MZApp");
        web.loadUrl("file:///android_asset/manche_zaboli.html");
        goImmersive();
    }

    private void goImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) goImmersive();
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else moveTaskToBack(true); // بازی را نمی‌بندد تا اتاق باز بماند
    }

    @Override
    protected void onDestroy() {
        if (server != null) server.stop();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private byte[] loadPage() throws Exception {
        if (pageBytes == null) {
            InputStream in = getAssets().open("manche_zaboli.html");
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            in.close();
            pageBytes = b.toByteArray();
        }
        return pageBytes;
    }

    private void js(final String code) {
        runOnUiThread(new Runnable() {
            public void run() { if (web != null) web.evaluateJavascript(code, null); }
        });
    }

    /** پل جاوااسکریپت ↔ اندروید (نام در صفحه: MZApp) */
    public class Bridge {
        @JavascriptInterface
        public int startServer() {
            try {
                if (server != null) { server.stop(); server = null; }
                LanServer s = new LanServer(PORT, loadPage(), new LanServer.Listener() {
                    public void onMessage(String id, String text) {
                        js("window.mzLanMsg&&window.mzLanMsg(" + JSONObject.quote(id) + "," + JSONObject.quote(text) + ")");
                    }
                    public void onClose(String id) {
                        js("window.mzLanClose&&window.mzLanClose(" + JSONObject.quote(id) + ")");
                    }
                });
                s.start();
                server = s;
                return PORT;
            } catch (Throwable e) {
                return -1;
            }
        }

        @JavascriptInterface
        public void stopServer() {
            if (server != null) { server.stop(); server = null; }
        }

        @JavascriptInterface
        public void send(String to, String json) {
            LanServer s = server;
            if (s == null) return;
            if (to != null && to.startsWith("ws:")) to = to.substring(3);
            s.send(to, json);
        }

        /** آدرس‌های IPv4 این گوشی (برای نمایش به بازیکن‌ها) */
        @JavascriptInterface
        public String urls() {
            JSONArray a = new JSONArray();
            List<String> ips = LanServer.localIps();
            for (String ip : ips) a.put(ip);
            return a.toString();
        }

        /** آدرس دروازهٔ وای‌فای؛ وقتی به هات‌اسپات میزبان وصلیم همان آدرس گوشی میزبان است */
        @JavascriptInterface
        @SuppressWarnings("deprecation")
        public String gateway() {
            try {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                int g = wm.getDhcpInfo().gateway;
                if (g == 0) return "";
                return (g & 0xff) + "." + ((g >> 8) & 0xff) + "." + ((g >> 16) & 0xff) + "." + ((g >> 24) & 0xff);
            } catch (Throwable e) {
                return "";
            }
        }
    }
}
